/* SnapIT extension popup.
   Talks to your deployed SnapIT site: POST /api/grab, then GET /api/download/<id>?probe=1 and the file itself. */
const PLATFORMS = [
  { name: 'YouTube', hosts: ['youtube.com', 'youtu.be'] },
  { name: 'Pinterest', hosts: ['pinterest.com', 'pin.it'] },
  { name: 'Snapchat', hosts: ['snapchat.com'] },
  { name: 'TikTok', hosts: ['tiktok.com'] },
  { name: 'X', hosts: ['twitter.com', 'x.com', 't.co'] },
  { name: 'Instagram', hosts: ['instagram.com'] },
];
const ICON_DL = '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round"><path d="M12 17V3"/><path d="m6 11 6 6 6-6"/><path d="M19 21H5"/></svg>';
const ICON_GEAR = '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="3"/><path d="M19.4 15a1.7 1.7 0 0 0 .3 1.8l.1.1a2 2 0 1 1-2.8 2.8l-.1-.1a1.7 1.7 0 0 0-1.8-.3 1.7 1.7 0 0 0-1 1.5V21a2 2 0 1 1-4 0v-.1a1.7 1.7 0 0 0-1.1-1.5 1.7 1.7 0 0 0-1.8.3l-.1.1a2 2 0 1 1-2.8-2.8l.1-.1a1.7 1.7 0 0 0 .3-1.8 1.7 1.7 0 0 0-1.5-1H3a2 2 0 1 1 0-4h.1a1.7 1.7 0 0 0 1.5-1.1 1.7 1.7 0 0 0-.3-1.8l-.1-.1a2 2 0 1 1 2.8-2.8l.1.1a1.7 1.7 0 0 0 1.8.3H9a1.7 1.7 0 0 0 1-1.5V3a2 2 0 1 1 4 0v.1a1.7 1.7 0 0 0 1 1.5 1.7 1.7 0 0 0 1.8-.3l.1-.1a2 2 0 1 1 2.8 2.8l-.1.1a1.7 1.7 0 0 0-.3 1.8V9a1.7 1.7 0 0 0 1.5 1H21a2 2 0 1 1 0 4h-.1a1.7 1.7 0 0 0-1.5 1Z"/></svg>';

const $ = id => document.getElementById(id);
const input = $('link-input'), form = $('form'), grabBtn = $('grab-btn'), status = $('status');
const settings = $('settings'), main = $('main'), siteInput = $('site-input'), settingsError = $('settings-error');
$('logo').innerHTML = ICON_DL;
$('settings-btn').innerHTML = ICON_GEAR;

let siteUrl = '';

const normalizeSite = v => {
  try { const u = new URL(v.trim()); if (!/^https?:$/.test(u.protocol)) return ''; return u.origin; } catch { return ''; }
};
const detectPlatform = v => {
  try {
    const u = new URL(v.trim());
    if (u.protocol !== 'https:') return null;
    const h = u.hostname.replace(/^www\./, '');
    return PLATFORMS.find(p => p.hosts.some(x => h === x || h.endsWith('.' + x))) || null;
  } catch { return null; }
};
const hasAccess = origin => chrome.permissions.contains({ origins: [origin + '/*'] });

function showSettings(show, msg) {
  settings.hidden = !show; main.hidden = show;
  settingsError.hidden = !msg; settingsError.textContent = msg || '';
  if (show) siteInput.value = siteUrl; 
}

$('settings-btn').addEventListener('click', () => showSettings(settings.hidden));

$('save-site').addEventListener('click', async () => {
  const origin = normalizeSite(siteInput.value);
  if (!origin) return showSettings(true, 'Enter a full address, like https://your-snapit.workers.dev');
  let granted = false;
  try { granted = await chrome.permissions.request({ origins: [origin + '/*'] }); } catch {}
  if (!granted) return showSettings(true, 'SnapIT needs permission to talk to that site. Press Save again and choose Allow.');
  siteUrl = origin;
  await chrome.storage.sync.set({ siteUrl });
  showSettings(false);
  detectTab();
});

function clearStatus() { status.replaceChildren(); }
function showError(msg) {
  clearStatus();
  const p = document.createElement('p'); p.className = 'error'; p.textContent = msg; status.appendChild(p);
}
function showLoading() {
  clearStatus();
  const d = document.createElement('div'); d.className = 'loading';
  d.innerHTML = '<span class="spin"></span><span>Finding your moment…</span>';
  status.appendChild(d);
}

async function postWithRetry(url, init) {
  let last;
  for (let i = 0; i < 3; i++) {
    try {
      const res = await fetch(url, init);
      const isJson = (res.headers.get('content-type') || '').includes('application/json');
      if (isJson || ![502, 503, 504].includes(res.status)) return res;
      last = res;
    } catch (e) { last = e; }
    await new Promise(r => setTimeout(r, 2500));
  }
  if (last instanceof Response) return last;
  throw last;
}

const fmtDuration = sec => {
  if (typeof sec !== 'number' || !isFinite(sec) || sec <= 0) return '';
  sec = Math.round(sec);
  const h = Math.floor(sec / 3600), m = Math.floor(sec % 3600 / 60), s = sec % 60;
  return (h ? h + ':' + String(m).padStart(2, '0') : m) + ':' + String(s).padStart(2, '0');
};

function el(tag, cls, text) {
  const e = document.createElement(tag);
  if (cls) e.className = cls;
  if (text != null) e.textContent = text;
  return e;
}

function showResults(options, info) {
  clearStatus();
  const card = el('div', 'card');
  const thumb = el('div', 'thumb');
  if (typeof info.thumbnail === 'string' && info.thumbnail.startsWith('https://')) {
    const img = document.createElement('img');
    img.alt = ''; img.referrerPolicy = 'no-referrer'; img.src = info.thumbnail;
    img.addEventListener('error', () => img.remove());
    thumb.appendChild(img);
  }
  const d = fmtDuration(info.duration);
  if (d) thumb.appendChild(el('span', 'time', d));
  const meta = el('div', 'meta');
  meta.appendChild(el('strong', '', info.title || 'Your video'));
  meta.appendChild(el('small', '', info.platform || ''));
  card.append(thumb, meta);
  status.appendChild(card);

  options.forEach(o => {
    const row = el('div', 'row');
    const infoBox = el('div', 'info');
    const strong = el('strong', '', o.label || '');
    strong.appendChild(el('span', '', String(o.format || '')));
    const small = el('small', '', o.filename || ''); small.title = o.filename || '';
    const err = el('small', 'err'); err.hidden = true;
    infoBox.append(strong, small, err);
    const btn = el('button', '', 'Download'); btn.type = 'button';
    btn.addEventListener('click', () => startDownload(btn, err, o));
    row.append(infoBox, btn);
    status.appendChild(row);
  });
}

async function startDownload(btn, err, o) {
  if (btn.disabled) return;
  btn.disabled = true; btn.textContent = 'Preparing…'; err.hidden = true;
  const href = siteUrl + o.url;
  try {
    const res = await fetch(href + '?probe=1');
    let data = {};
    try { data = await res.json(); } catch {}
    if (!res.ok || data.error) throw new Error(data.error || 'The file could not be fetched. Try another option, or grab the link again.');
    await chrome.downloads.download({ url: href + '?t=' + Date.now(), filename: o.filename ? o.filename.replace(/[\\/:*?"<>|]/g, '_') : undefined, saveAs: false });
    btn.textContent = 'Started ✓';
    setTimeout(() => { btn.textContent = 'Download'; btn.disabled = false; }, 2500);
  } catch (e) {
    err.textContent = e instanceof TypeError ? 'Could not reach the SnapIT server. Check your connection and try again.' : e.message;
    err.hidden = false; btn.textContent = 'Download'; btn.disabled = false;
  }
}

form.addEventListener('submit', async e => {
  e.preventDefault();
  const value = input.value.trim();
  if (!value) return showError('Paste a video link first.');
  if (!detectPlatform(value)) return showError('Paste a valid HTTPS video link from YouTube, Pinterest, Snapchat, TikTok, X or Instagram.');
  if (!siteUrl) return showSettings(true);
  grabBtn.disabled = true; input.disabled = true; showLoading();
  try {
    const res = await postWithRetry(siteUrl + '/api/grab', {
      method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ url: value })
    });
    let data;
    try { data = await res.json(); } catch { data = { error: 'The SnapIT server did not respond properly. Try again in a moment.' }; }
    if (data.error) showError(data.error);
    else if (Array.isArray(data.options) && data.options.length) showResults(data.options, data);
    else showError('Nothing came back for that link. Try another one.');
  } catch {
    showError('Could not reach the SnapIT server. Check your connection, then try again.');
  } finally {
    grabBtn.disabled = false; input.disabled = false;
  }
});

/* If the current tab is a supported video page, fill it in (not grabbed until you press Grab). */
async function detectTab() {
  try {
    const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
    const p = tab && tab.url && detectPlatform(tab.url);
    if (p) {
      input.value = tab.url;
      const d = $('detected'); d.textContent = 'Detected a ' + p.name + ' page — press Grab.'; d.hidden = false;
    }
  } catch {}
}

(async () => {
  const stored = await chrome.storage.sync.get('siteUrl');
  siteUrl = stored.siteUrl || '';
  if (!siteUrl || !(await hasAccess(siteUrl))) return showSettings(true, siteUrl ? 'Permission for your SnapIT site is missing. Press Save to allow it again.' : '');
  detectTab();
  input.focus();
})();
