# SnapIT browser extension (Chrome, Edge, Brave, Opera)

Manifest V3 extension that uses your deployed SnapIT site (the Cloudflare Worker + Render backend) to grab videos.

## Install (unpacked)
1. Unzip this folder.
2. Open `chrome://extensions` (Edge: `edge://extensions`), switch on **Developer mode**.
3. Click **Load unpacked** and pick this folder.
4. Click the SnapIT icon, enter your SnapIT site address (for example `https://snapit.yourname.workers.dev`), press **Save** and choose **Allow**.

## Use
- Open a YouTube / Pinterest / Snapchat / TikTok / X / Instagram page, click the icon: the link is filled in, press **Grab**, then **Download** on a quality.
- Right-click any link, page or video > **Grab with SnapIT** opens your SnapIT site with the link pasted in.

## Notes
- The extension needs your site's address because the backend is behind your Worker (which holds the PROXY_SECRET). Nothing is sent anywhere else.
- Permissions: `activeTab` (read the current page's address), `storage` (remember your site address), `downloads` (save files), `contextMenus` (right-click item). Access to your site is requested when you save its address.
- Firefox: not included (Firefox does not support MV3 service workers the same way).
- Publishing to the Chrome Web Store: zip the folder contents, upload at the developer dashboard, and add 1280x800 screenshots.
