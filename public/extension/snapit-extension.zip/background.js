/* SnapIT extension - background service worker.
   Adds a right-click item "Grab with SnapIT" on links, pages and videos. It opens your SnapIT site
   with the link already pasted in. */
const MENU_ID = 'snapit-grab';

chrome.runtime.onInstalled.addListener(() => {
  chrome.contextMenus.create({
    id: MENU_ID,
    title: 'Grab with SnapIT',
    contexts: ['link', 'page', 'video']
  });
});

chrome.contextMenus.onClicked.addListener(async (info) => {
  if (info.menuItemId !== MENU_ID) return;
  const target = info.linkUrl || info.srcUrl || info.pageUrl;
  const { siteUrl } = await chrome.storage.sync.get('siteUrl');
  if (!siteUrl) { chrome.tabs.create({ url: chrome.runtime.getURL('popup.html') }); return; } // popup page doubles as the setup screen
  chrome.tabs.create({ url: siteUrl + '/?url=' + encodeURIComponent(target) });
});
